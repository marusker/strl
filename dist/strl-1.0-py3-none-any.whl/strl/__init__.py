#strlclassファイルからSTRLクラスを読み込む
from .strlclass import STRL

#メソッドのみを読み込むときは"from . import strlclass" とする